# QUICKSTART - TEST IMMEDIATELY

## ðŸš€ 3-Minute Setup

### Step 1: Extract & Install (2 minutes)
```bash
# Extract the zip file
unzip courtdominion-frontend.zip
cd courtdominion-frontend

# Install dependencies
npm install
```

### Step 2: Start Backend (30 seconds)
```bash
# In your backend directory (separate terminal)
docker-compose up

# Wait for: "Application startup complete"
# Backend should be at http://localhost:8000
```

### Step 3: Start Frontend (30 seconds)
```bash
# In the frontend directory
npm run dev

# Should see: "Local: http://localhost:5173/"
# Open this URL in your browser
```

## âœ… What You Should See

1. **Dark theme** with clean layout
2. **Header** with "CourtDominion" logo and navigation
3. **Homepage** with:
   - Large headline (from API)
   - Subheadline (from API)
   - Green success box showing "âœ… Phase 1 Complete"
   - Checklist of completed features
4. **Footer** with copyright and links
5. **No console errors** in browser DevTools

## ðŸ§ª Quick Tests

### Test 1: API Connection
- Look for headline text that came from your API
- Click "View API Response (Debug)" to see raw data
- Should show your content from `/api/content` endpoint

### Test 2: Navigation
- Click "Projections" → See placeholder page
- Click "Insights" → See placeholder page  
- Click "Home" → Return to homepage

### Test 3: Environment Vars
```bash
# Check that API URL is correct
cat .env

# Should show: VITE_API_BASE_URL=http://localhost:8000
```

## ❌ Common Issues

### Issue: "Cannot connect to API"
**Fix:** Make sure Docker backend is running
```bash
docker ps
# Should see your backend container running
```

### Issue: "Port 5173 already in use"
**Fix:** Kill the process or use different port
```bash
npm run dev -- --port 5174
```

### Issue: "npm install fails"
**Fix:** Check Node version
```bash
node --version  # Should be 18+
npm --version   # Should be 9+
```

## âœ… Approval Checklist

Before approving Phase 1:
- [ ] Project installs without errors
- [ ] Dev server starts successfully
- [ ] Homepage loads in browser
- [ ] API connection works (headline shows from API)
- [ ] Navigation works (all 3 pages accessible)
- [ ] No console errors
- [ ] Dark theme looks good
- [ ] Header and footer render correctly

## ðŸ"ž If You Have Issues

1. Check that backend is running: `curl http://localhost:8000/api/content`
2. Check browser console for errors (F12)
3. Check terminal output for build errors
4. Verify `.env` file exists with correct URL

## 🎯 Next Steps

**If everything works:**
✅ Reply with "Phase 1 approved"
➡️  I'll build Phase 2 (Full Homepage)

**If there are issues:**
❌ Share the error message
ðŸ"§ I'll fix it immediately

---

**Expected time to test:** 5 minutes
**What we're verifying:** Basic setup, API connection, routing
