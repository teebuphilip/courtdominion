# CourtDominion Frontend - Phase 1

NBA Fantasy Basketball Platform - React Frontend

## ðŸš€ Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Backend API running (Docker: `http://localhost:8000`)

### Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Open browser to http://localhost:5173
```

## ðŸ"§ Configuration

### Environment Variables

**Local Development (`.env`):**
```bash
VITE_API_BASE_URL=http://localhost:8000
```

**Production (`.env.production`):**
```bash
VITE_API_BASE_URL=https://courtdominion.up.railway.app
```

## âœ… Phase 1 Checklist

- [x] Vite + React 18 setup
- [x] TailwindCSS configured (dark mode)
- [x] React Router installed
- [x] React Query configured
- [x] Axios HTTP client
- [x] API service layer (`src/services/api.js`)
- [x] Custom hooks for data fetching
- [x] Layout components (Header, Footer, Layout)
- [x] Basic HomePage with API connection test
- [x] Environment variable configuration
- [x] Placeholder pages for routing

## ðŸ§ª Testing Phase 1

### 1. Start Backend (Docker)
```bash
# In your backend directory
docker-compose up
# Backend should be at http://localhost:8000
```

### 2. Start Frontend
```bash
# In this directory
npm run dev
# Frontend will be at http://localhost:5173
```

### 3. Verify API Connection
- Open http://localhost:5173
- Should see "Phase 1 Complete" message
- Check that dynamic content loads from API
- Open browser console - should have no errors
- Click "View API Response" to see content data

## 🎨 Design System

### Colors
- **Background:** `#0a0a0a` (gray-950)
- **Cards:** `#1a1a1a` (gray-900)
- **Borders:** `#2a2a2a` (gray-800)
- **Text:** `#e5e5e5` (gray-200)

### Risk Badge Colors
- **Low:** Green `#22c55e`
- **Medium:** Yellow `#eab308`
- **High:** Red `#ef4444`

## 🚨 Critical Rules

1. **NO HARDCODED TEXT** - Everything must come from `/api/content`
2. **Use environment variables** - Never hardcode API URLs
3. **Dark mode only** - Light mode not supported in Phase 1
4. **Desktop-first** - Optimized for 1440px, mobile-readable

## 🎯 Success Criteria

Phase 1 is complete when:
- [x] Project compiles without errors
- [x] Layout (header/footer) renders correctly
- [x] API connection works (content loads)
- [x] Navigation routing works
- [x] No console errors
- [x] Dark mode styling applied

---

**Status:** âœ… Phase 1 Complete - Ready for approval
**Next:** Phase 2 - Full Homepage Build
