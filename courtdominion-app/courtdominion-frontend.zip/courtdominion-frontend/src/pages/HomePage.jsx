/**
 * HomePage Component
 * Landing page - will be fully built in Phase 2
 * Currently shows basic layout and tests API connection
 */

import { useContent } from '../hooks/useContent';

export default function HomePage() {
  const { data: content, isLoading, error } = useContent();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl text-gray-400">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl text-red-400">
          Error connecting to API: {error.message}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div className="text-center space-y-8">
        {/* Hero Section */}
        <h1 className="text-5xl font-bold text-white">
          {content?.homepage?.headline || 'NBA Fantasy Projections'}
        </h1>
        
        <p className="text-xl text-gray-400 max-w-2xl mx-auto">
          {content?.homepage?.subheadline || 'Data-driven insights for fantasy basketball'}
        </p>

        {/* API Connection Test */}
        <div className="mt-12 p-6 bg-gray-900 rounded-lg border border-gray-800">
          <h2 className="text-2xl font-semibold text-green-400 mb-4">
            âœ… Phase 1 Complete: Layout & API Connection
          </h2>
          <div className="text-left text-gray-300 space-y-2">
            <p>âœ… Vite + React setup working</p>
            <p>âœ… Tailwind CSS configured</p>
            <p>âœ… React Router installed</p>
            <p>âœ… React Query configured</p>
            <p>âœ… API service layer created</p>
            <p>âœ… Layout components (Header/Footer) working</p>
            <p>âœ… Dynamic content loading from {import.meta.env.VITE_API_BASE_URL}</p>
            <p className="mt-4 text-yellow-400">
              ðŸ›' READY FOR APPROVAL - Phase 2 (Full Homepage) awaits
            </p>
          </div>
        </div>

        {/* Debug Info */}
        <details className="mt-8 text-left">
          <summary className="cursor-pointer text-gray-400 hover:text-white">
            View API Response (Debug)
          </summary>
          <pre className="mt-4 p-4 bg-gray-900 rounded text-xs text-gray-300 overflow-auto">
            {JSON.stringify(content, null, 2)}
          </pre>
        </details>
      </div>
    </div>
  );
}
