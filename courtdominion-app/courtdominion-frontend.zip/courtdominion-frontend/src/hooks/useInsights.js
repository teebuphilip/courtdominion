/**
 * useInsights Hook
 * Fetches waiver wire insights from /api/insights endpoint
 * Returns recommendations with reasoning and value scores
 */

import { useQuery } from '@tanstack/react-query';
import { apiService } from '../services/api';

export function useInsights(params = {}) {
  return useQuery({
    queryKey: ['insights', params],
    queryFn: async () => {
      const response = await apiService.getInsights(params);
      return response.data;
    },
    staleTime: 5 * 60 * 1000, // Fresh for 5 minutes
    cacheTime: 10 * 60 * 1000, // Keep in cache for 10 minutes
    retry: 2,
  });
}
