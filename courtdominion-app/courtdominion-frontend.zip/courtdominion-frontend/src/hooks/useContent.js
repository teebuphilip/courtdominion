/**
 * useContent Hook
 * Fetches dynamic content from /api/content endpoint
 * This content powers ALL text on the site (headlines, copy, labels, etc.)
 * 
 * CRITICAL: Never hardcode text - always use this hook!
 */

import { useQuery } from '@tanstack/react-query';
import { apiService } from '../services/api';

export function useContent() {
  return useQuery({
    queryKey: ['content'],
    queryFn: async () => {
      const response = await apiService.getContent();
      return response.data;
    },
    staleTime: 60 * 60 * 1000, // Content is fresh for 1 hour
    cacheTime: 60 * 60 * 1000, // Keep in cache for 1 hour
    retry: 3, // Retry failed requests 3 times
  });
}
