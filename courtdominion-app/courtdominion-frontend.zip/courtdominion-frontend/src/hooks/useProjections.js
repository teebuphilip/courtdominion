/**
 * useProjections Hook
 * Fetches player projections from /api/projections endpoint
 * Supports filtering, sorting, and limiting results
 */

import { useQuery } from '@tanstack/react-query';
import { apiService } from '../services/api';

export function useProjections(params = {}) {
  return useQuery({
    queryKey: ['projections', params],
    queryFn: async () => {
      const response = await apiService.getProjections(params);
      return response.data;
    },
    staleTime: 5 * 60 * 1000, // Fresh for 5 minutes
    cacheTime: 10 * 60 * 1000, // Keep in cache for 10 minutes
    retry: 2,
  });
}
