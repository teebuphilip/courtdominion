/**
 * usePlayer Hook
 * Fetches detailed player information from /api/players/{id} endpoint
 * Includes projection, insight, and risk data
 */

import { useQuery } from '@tanstack/react-query';
import { apiService } from '../services/api';

export function usePlayer(playerId) {
  return useQuery({
    queryKey: ['player', playerId],
    queryFn: async () => {
      const response = await apiService.getPlayer(playerId);
      return response.data;
    },
    enabled: !!playerId, // Only run query if playerId exists
    staleTime: 5 * 60 * 1000, // Fresh for 5 minutes
    cacheTime: 10 * 60 * 1000, // Keep in cache for 10 minutes
    retry: 2,
  });
}
