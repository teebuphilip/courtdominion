/**
 * useRisk Hook
 * Fetches risk assessment data from /api/risk endpoint
 * Used to merge risk badges into projections table
 */

import { useQuery } from '@tanstack/react-query';
import { apiService } from '../services/api';

export function useRisk(params = {}) {
  return useQuery({
    queryKey: ['risk', params],
    queryFn: async () => {
      const response = await apiService.getRisk(params);
      return response.data;
    },
    staleTime: 5 * 60 * 1000, // Fresh for 5 minutes
    cacheTime: 10 * 60 * 1000, // Keep in cache for 10 minutes
    retry: 2,
  });
}
