/**
 * Footer Component
 * Site-wide footer with copyright and links
 * Uses dynamic content from /api/content
 */

import { useContent } from '../../hooks/useContent';

export default function Footer() {
  const { data: content, isLoading } = useContent();

  return (
    <footer className="bg-gray-900 border-t border-gray-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          {/* Copyright */}
          <div className="text-gray-400 text-sm">
            {isLoading ? (
              'Â© 2026 CourtDominion. All rights reserved.'
            ) : (
              content?.footer?.copyright || 'Â© 2026 CourtDominion. All rights reserved.'
            )}
          </div>

          {/* Links */}
          <div className="flex space-x-6">
            <a
              href="#"
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              {isLoading ? 'Privacy' : (content?.footer?.privacy || 'Privacy')}
            </a>
            <a
              href="#"
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              {isLoading ? 'Terms' : (content?.footer?.terms || 'Terms')}
            </a>
            <a
              href="#"
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              {isLoading ? 'Contact' : (content?.footer?.contact || 'Contact')}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
