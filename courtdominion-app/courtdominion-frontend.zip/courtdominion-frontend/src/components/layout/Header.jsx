/**
 * Header Component
 * Site-wide navigation header
 * Uses dynamic content from /api/content for navigation labels
 */

import { Link } from 'react-router-dom';
import { useContent } from '../../hooks/useContent';

export default function Header() {
  const { data: content, isLoading } = useContent();

  return (
    <header className="bg-gray-900 border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold text-white">
              CourtDominion
            </span>
          </Link>

          {/* Navigation */}
          <nav className="flex space-x-8">
            <Link
              to="/"
              className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
            >
              {isLoading ? 'Home' : (content?.navigation?.home || 'Home')}
            </Link>
            <Link
              to="/projections"
              className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
            >
              {isLoading ? 'Projections' : (content?.navigation?.projections || 'Projections')}
            </Link>
            <Link
              to="/insights"
              className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
            >
              {isLoading ? 'Insights' : (content?.navigation?.insights || 'Insights')}
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
