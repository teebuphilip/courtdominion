/**
 * API Service Layer
 * Centralizes all backend API calls
 * Uses environment variable for base URL to support local/production modes
 */

import axios from 'axios';

// Get API base URL from environment variable
// Defaults to localhost:8000 for local development
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000, // 10 second timeout
  headers: {
    'Content-Type': 'application/json',
  },
});

// API service object with all endpoint methods
export const apiService = {
  /**
   * Get dynamic content for all pages
   * Returns: { homepage: {...}, projections: {...}, etc. }
   */
  getContent: () => api.get('/api/content'),

  /**
   * Get player projections
   * @param {Object} params - Query parameters (limit, sort_by, order)
   */
  getProjections: (params = {}) => api.get('/api/projections', { params }),

  /**
   * Get single player details by ID
   * @param {string} id - Player ID
   */
  getPlayer: (id) => api.get(`/api/players/${id}`),

  /**
   * Get waiver wire insights
   * @param {Object} params - Query parameters (limit)
   */
  getInsights: (params = {}) => api.get('/api/insights', { params }),

  /**
   * Get risk assessments for players
   * @param {Object} params - Query parameters (limit)
   */
  getRisk: (params = {}) => api.get('/api/risk', { params }),
};

export default apiService;
