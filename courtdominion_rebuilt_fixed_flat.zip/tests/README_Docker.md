See docker-compose.yml. Use docker-compose up --build
